do local _ = {
  about_text = "",
  enabled_plugins = {
    "admin",
    "onservice",
    "inrealm",
    "ingroup",
    "inpm",
    "banhammer",
    "stats",
    "anti_spam",
    "owners",
    "arabic_lock",
    "set",
    "get",
    "broadcast",
    "invite",
    "all",
    "leave_ban",
    "supergroup",
    "supergroups_fa",
    "whitelist",
    "filter",
    "filter_fa",
    "plugins",
    "serverinfo",
    "version",
    "msg_checks",
    "helpfa",
    "helpen",
    "expire",
    "banhammer_fa"
  },
  help_text = "",
  help_text_realm = "",
  help_text_super = "",
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    254504515
  }
}
return _
end